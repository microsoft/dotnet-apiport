using System;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using WorkflowManagement;

namespace Functions
{
    public static class ProcessWorkflowQueue
    {
        public static Func<IWorkflowActionFactory> GetActionFactory { get; set; } = () => new WorkflowActionFactory();

        [FunctionName("ProcessWorkflowQueue")]
        [return: Queue("%StorageQueueName%")]
        public static async Task<WorkflowQueueMessage> Run([QueueTrigger("%StorageQueueName%", Connection = "AzureWebJobsStorage")]WorkflowQueueMessage workflowMessage, ILogger log)
        {
            var workflowMgr = WorkflowManager.GetInstance(GetActionFactory());
            return await workflowMgr.ExecuteActionsToNextStage(workflowMessage);
        }
    }
}
